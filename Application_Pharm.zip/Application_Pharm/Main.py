from SignUp_Login import StartApplication

if __name__ == "__main__":
    StartApplication()

